Ripped by Hell Inspector (Submitter name: Hawkodile)
https://www.vg-resource.com/user-39500.html

Backface culling is needed for the cel outline.

Credit is appreciated but not needed.

Thank you and Have a great day! Have fun using this model.